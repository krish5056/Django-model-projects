from django.apps import AppConfig


class AcAdminConfig(AppConfig):
    name = 'ac_admin'
