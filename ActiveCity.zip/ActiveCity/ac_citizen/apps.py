from django.apps import AppConfig


class AcCitizenConfig(AppConfig):
    name = 'ac_citizen'
