from django.apps import AppConfig


class AcLoginConfig(AppConfig):
    name = 'ac_login'
