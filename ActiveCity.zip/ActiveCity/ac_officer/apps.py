from django.apps import AppConfig


class AcOfficerConfig(AppConfig):
    name = 'ac_officer'
