# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

class imdb(models.Model):
    popularity = models.FloatField( null = True)
    director = models.CharField( max_length=21, null = True,blank=True)
    genre = models.CharField( max_length=12, null = True)
    imdb_score = models.FloatField( null = True)
    name = models.CharField(max_length=69, null = True)

    def __str__(self):
        return "{}  {}  {}  {}  {}".format(self.popularity, self.director, self.genre, self.imdb_score, self.name)
