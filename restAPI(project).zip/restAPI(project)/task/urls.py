from django.conf.urls import url, include
from . views import *



urlpatterns = [
    url(r'^$', ImdbViewSet.as_view({'get': 'list'}), name="imdbview"),
    url(r'^admin/(?P<pk>[0-9]+)$', AdminProfileGet.as_view()),
    url(r'^admin/',AdminProfile.as_view())
    #url(r'^profile/', AdminProfile.as_view()),


]