# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from rest_framework import viewsets
from rest_framework import generics
from django.shortcuts import render
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from .serializers import ImdbSerializer
from django_filters.rest_framework import DjangoFilterBackend
from .models import imdb
from rest_framework.permissions import IsAuthenticated
# Create your views here.


class ImdbViewSet(viewsets.ModelViewSet):
    queryset = imdb.objects.all()
    filter_backends = (DjangoFilterBackend,)
    serializer_class = ImdbSerializer
    filter_fields = ('popularity', 'director', 'genre', 'imdb_score','name')
    search_fields = ('popularity', 'director', 'genre', 'imdb_score','name')





class AdminProfile(generics.ListCreateAPIView):
    queryset = imdb.objects.all()
    serializer_class = ImdbSerializer
    permission_classes = (IsAuthenticated,)

    def get(self, request, format=None):
        details =  imdb.objects.all()
        queryset = self.get_queryset()
        serializer = ImdbSerializer(details, many=True)
        return Response(serializer.data)

    def post(self, request, format=None):
        serializer = ImdbSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'Status': "0", 'Message': "Movie Created!"})



class AdminProfileGet(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = ImdbSerializer
    permission_classes = (IsAuthenticated,)


    def get(self, request, pk):

        details = imdb.objects.get(id=pk)
        serializer= ImdbSerializer(details)
        return Response(serializer.data)



    def put(self, request, pk, format=None):
        #import pdb;pdb.set_trace()
        details = get_object_or_404(imdb.objects.all(), id=pk)
        serializer = ImdbSerializer(instance=details, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'Status': "0", 'Message': " movie Successfully Updated!"})

        return Response({'Status': "1", 'Message': "movie Updation Failed!"})

    def delete(self, request, pk, format=None):

        details =imdb.objects.get(id=pk)
        print(details)

        details.delete()

        return Response({'Status': "0", 'Message': "Successfully Deleted!"})
